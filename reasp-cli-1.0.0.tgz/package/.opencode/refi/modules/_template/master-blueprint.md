 # Master Blueprint

 Pendiente.
